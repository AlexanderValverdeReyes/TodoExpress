package Control;

import DAO.ClienteDAO;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ClientesControl {

    private final List<ClienteDAO> listaClientes = new ArrayList<>();

public void agregarClienteATablaTemporal(JTextField Nombres, JTextField Apellidos, JTextField DNI, JTextField Telefono, JTable tablatempcliente) {
    String nombre = Nombres.getText().trim();
    String apellido = Apellidos.getText().trim();
    String dni = DNI.getText().trim();
    String telefono = Telefono.getText().trim();
              

    if (nombre.isEmpty() || apellido.isEmpty() || dni.isEmpty() || telefono.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Todos los campos deben estar completos");
        return;
    }

    if (!dni.matches("\\d{8}")) {
        JOptionPane.showMessageDialog(null, "El DNI debe tener 8 dígitos numéricos");
        return;
    }

    if (!telefono.matches("\\d{9}")) {
        JOptionPane.showMessageDialog(null, "El teléfono debe tener 9 dígitos numéricos");
        return;
    }

    // Verifica que no se duplique el DNI en la lista
    for (ClienteDAO cliente : listaClientes) {
        if (cliente.getDNI().equals(dni)) {
            JOptionPane.showMessageDialog(null, "Este DNI ya se agregó a la lista.");
            return;
        }
    }

    // Crear objeto ClienteDAO y agregar a lista
    ClienteDAO cliente = new ClienteDAO();
    try {
        cliente.setNombres(nombre);
        cliente.setApellidos(apellido);
        cliente.setDNI(dni);
        cliente.setTelefono(telefono);
    } catch (IllegalArgumentException ex) {
        JOptionPane.showMessageDialog(null, "Error al registrar cliente: " + ex.getMessage());
        return;
    }

    listaClientes.add(cliente);

    // Agregar a la tabla visual
    DefaultTableModel modelo = new DefaultTableModel(
    new String[]{"NOMBRES", "APELLIDOS", "DNI", "TELEFONO"}, 0
) {
    @Override
    public boolean isCellEditable(int row, int column) {
        return false;
    }
};

tablatempcliente.setModel(modelo);
modelo.addRow(new Object[]{
    cliente.getNombres(),
    cliente.getApellidos(),
    cliente.getDNI(),
    cliente.getTelefono()
});
    // Limpiar campos
    Nombres.setText("");
    Apellidos.setText("");
    DNI.setText("");
    Telefono.setText("");
}
    
    // Muestra los datos de la base de datos en la JTable
    public void mostrarclientes(JTable tablaClientes) {
        Conexion objetoConexion = new Conexion();

        DefaultTableModel modelo = new DefaultTableModel(
            new String[]{"ID","NOMBRES", "APELLIDOS", "DNI", "TELEFONO"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        String sql = "SELECT  ID, Nombres, Apellidos, DNI, Telefono FROM Clientes";

        try (Connection conn = objetoConexion.establecerConexion();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String[] datos = new String[5]; //array
                datos[0] = rs.getString("ID");
                datos[1] = rs.getString("Nombres");
                datos[2] = rs.getString("Apellidos");
                datos[3] = rs.getString("DNI");
                datos[4] = rs.getString("Telefono");
                modelo.addRow(datos);
            }

            tablaClientes.setModel(modelo);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar: " + e);
        } finally {
            objetoConexion.cerrarConexion();
        }
    }

    // Agrega un nuevo cliente a la base de datos
   public void agregarCliente(JTable tablatempcliente, JTable tablaCliente) {
    Conexion objetoConexion = new Conexion();
    String verificarDniSQL = "SELECT COUNT(*) FROM Clientes WHERE DNI = ?";
    String consultaInsertar = "INSERT INTO Clientes (Nombres, Apellidos, DNI, Telefono) VALUES (?, ?, ?, ?)";

    try (Connection conn = objetoConexion.establecerConexion()) {
        DefaultTableModel modeloTemp = (DefaultTableModel) tablatempcliente.getModel();
        int filas = modeloTemp.getRowCount();

        for (int i = 0; i < filas; i++) {
            String nombre = modeloTemp.getValueAt(i, 0).toString();
            String apellido = modeloTemp.getValueAt(i, 1).toString();
            String dni = modeloTemp.getValueAt(i, 2).toString();
            String telefono = modeloTemp.getValueAt(i, 3).toString();

            // Verificar si el DNI ya existe
            try (PreparedStatement psVerificar = conn.prepareStatement(verificarDniSQL)) {
                psVerificar.setString(1, dni);
                ResultSet rs = psVerificar.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(null, "El DNI " + dni + " ya está registrado. Se omitirá ese registro.");
                    continue; // Salta a la siguiente fila
                }
            }

            // Insertar el cliente si no está repetido
            try (PreparedStatement psInsertar = conn.prepareStatement(consultaInsertar)) {
                psInsertar.setString(1, nombre);
                psInsertar.setString(2, apellido);
                psInsertar.setString(3, dni);
                psInsertar.setString(4, telefono);
                psInsertar.executeUpdate();
            }
        }

        JOptionPane.showMessageDialog(null, "Clientes agregados correctamente desde la tabla temporal.");

        // Ahora mostrar los datos actualizados en tablaCliente
        mostrarclientes(tablaCliente);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al agregar clientes desde tabla temporal: " + e.toString());
    } finally {
        objetoConexion.cerrarConexion();
    }

        
}
   public void modificarClienteEnTablaTemporal(JTable tablatempcliente, JTextField Nombres, JTextField Apellidos, JTextField DNI, JTextField Telefono) {
    int filaSeleccionada = tablatempcliente.getSelectedRow();

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Debe seleccionar una fila para modificar.");
        return;
    }

    if (Nombres.getText().isEmpty() || Apellidos.getText().isEmpty() || DNI.getText().isEmpty() || Telefono.getText().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Todos los campos deben estar completos.");
        return;
    }

    DefaultTableModel modelo = (DefaultTableModel) tablatempcliente.getModel();
    modelo.setValueAt(Nombres.getText(), filaSeleccionada, 0);
    modelo.setValueAt(Apellidos.getText(), filaSeleccionada, 1);
    modelo.setValueAt(DNI.getText(), filaSeleccionada, 2);
    modelo.setValueAt(Telefono.getText(), filaSeleccionada, 3);

    JOptionPane.showMessageDialog(null, "Cliente modificado correctamente en la tabla temporal.");
}
   
   public void eliminarClienteDeTablaTemporal(JTable tablatempcliente) {
    int filaSeleccionada = tablatempcliente.getSelectedRow();

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Debe seleccionar una fila para eliminar.");
        return;
    }

    DefaultTableModel modelo = (DefaultTableModel) tablatempcliente.getModel();
    modelo.removeRow(filaSeleccionada);

    JOptionPane.showMessageDialog(null, "Cliente eliminado de la tabla temporal.");
}
   public void cargarClienteTemporalEnCampos(JTable tablatempcliente, JTextField Nombres, JTextField Apellidos, JTextField DNI, JTextField Telefono) {
    try {
        int fila = tablatempcliente.getSelectedRow(); 
        if (fila != -1) {
            Nombres.setText(tablatempcliente.getValueAt(fila, 0).toString());
            Apellidos.setText(tablatempcliente.getValueAt(fila, 1).toString());
            DNI.setText(tablatempcliente.getValueAt(fila, 2).toString());
            Telefono.setText(tablatempcliente.getValueAt(fila, 3).toString());
        } else {
            JOptionPane.showMessageDialog(null, "Debes seleccionar una fila.");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al seleccionar el cliente temporal: " + e.toString());
    }
}
   
public void cargarClienteEnCampos(JTable tablaClientes, JTextField ID, JTextField Nombres, JTextField Apellidos, JTextField DNI, JTextField Telefono) {
    try {
           int fila = tablaClientes.getSelectedRow(); 
           if (fila != -1) {
               
            ID.setText(tablaClientes.getValueAt(fila, 0).toString());
            Nombres.setText(tablaClientes.getValueAt(fila, 1).toString());
            Apellidos.setText(tablaClientes.getValueAt(fila, 2).toString());
            DNI.setText(tablaClientes.getValueAt(fila, 3).toString());
            Telefono.setText(tablaClientes.getValueAt(fila, 4).toString());
        }   
           else{
               JOptionPane.showMessageDialog(null, "No se pudo seleccionar");
           }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error de seleccion:" +e.toString());
    }
        
        
           
    }

    public void modificarCliente(JTextField ID, JTextField Nombres, JTextField Apellidos, JTextField DNI, JTextField Telefono) {
    if (ID.getText().isEmpty()|| Nombres.getText().isEmpty() || Apellidos.getText().isEmpty() || DNI.getText().isEmpty() || Telefono.getText().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Todos los campos deben estar completos");
        return;
    }

    Conexion objetoConexion = new Conexion();
    //String verificarDniSQL = "SELECT COUNT(*) FROM Clientes WHERE DNI = ?";
    String consulta = "UPDATE Clientes SET Nombres = ?, Apellidos = ?, DNI = ?, Telefono  =? WHERE ID = ?;";

    try (Connection conn = objetoConexion.establecerConexion()) {
        try (PreparedStatement psInsertar = conn.prepareStatement(consulta)) {
            psInsertar.setString(1, Nombres.getText());
            psInsertar.setString(2, Apellidos.getText());
            psInsertar.setString(3, DNI.getText());
            psInsertar.setString(4, Telefono.getText());
            psInsertar.setString(5, ID.getText());
            psInsertar.executeUpdate();
            JOptionPane.showMessageDialog(null, "Se modifico el registro correctamente");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al modificar el registro: " + e.toString());
    } finally {
        objetoConexion.cerrarConexion();
    }
}
    
    
    public void eliminarCliente(JTextField id) {
    Conexion objetoConexion = new Conexion();

    String consulta = "DELETE FROM Clientes WHERE ID = ?";

    try (Connection conn = objetoConexion.establecerConexion();
         PreparedStatement ps = conn.prepareStatement(consulta)) {

        if (id.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar un ID para eliminar.");
            return;
        }

        ps.setString(1, id.getText());
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            JOptionPane.showMessageDialog(null, "Se eliminó el registro correctamente.");
        } else {
            JOptionPane.showMessageDialog(null, "No se encontró un cliente con ese ID.");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al eliminar el registro: " + e.toString());
    } finally {
        objetoConexion.cerrarConexion();
    }
}

    public void limpiarCampos(JTextField... campos) {
        for (JTextField campo : campos) {
            campo.setText("");
        }
    }
    
    public void buscarClientesPorTexto(JTable tabla, String texto) {
    DefaultTableModel modelo = new DefaultTableModel(
        new String[]{"ID", "NOMBRES", "APELLIDOS", "DNI", "TELEFONO"}, 0
    ) {
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    Conexion conn = new Conexion();
    String sql = "SELECT * FROM Clientes WHERE Nombres LIKE ? OR DNI LIKE ?";

    try (Connection con = conn.establecerConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, "%" + texto + "%");
        ps.setString(2, "%" + texto + "%");

        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            modelo.addRow(new Object[]{
                rs.getInt("ID"),
                rs.getString("Nombres"),
                rs.getString("Apellidos"),
                rs.getString("DNI"),
                rs.getString("Telefono")
            });
        }
        tabla.setModel(modelo);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al buscar clientes: " + e.toString());
    } finally {
        conn.cerrarConexion();
    }
}
}
                