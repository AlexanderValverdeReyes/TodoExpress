/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

/**
 *
 * @author alexa
 */
import DAO.ProductoDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ProductoControl {
    
private final List<ProductoDAO> listaProductos = new ArrayList<>();
public List<ProductoDAO> getListaProductos() {
    return listaProductos;
}

public void agregarProductoATablaTemporal(JTextField Nombre, JTextField Descripcion, JTextField Precio, JTextField Cantidad, JTextField Categoria, JTable tempprod) {
    String nombre = Nombre.getText().trim();
    String descripcion = Descripcion.getText().trim();
    String precioStr = Precio.getText().trim();
    String cantidadStr = Cantidad.getText().trim();
    String categoria = Categoria.getText().trim();

    if (nombre.isEmpty() || descripcion.isEmpty() || precioStr.isEmpty() || cantidadStr.isEmpty() || categoria.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Todos los campos deben estar completos");
        return;
    }

    double precio;
    int cantidad;
    try {
        precio = Double.parseDouble(precioStr);
        cantidad = Integer.parseInt(cantidadStr);
        if (precio < 0 || cantidad < 0) {
            JOptionPane.showMessageDialog(null, "Precio y cantidad deben ser positivos.");
            return;
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Precio debe ser decimal y cantidad un número entero.");
        return;
    }

    for (ProductoDAO producto : listaProductos) {
        if (producto.getNombre().equalsIgnoreCase(nombre)) {
            JOptionPane.showMessageDialog(null, "Este producto ya fue agregado a la lista.");
            return;
        }
    }

    // Crear objeto ProductoDAO y agregarlo
    ProductoDAO producto = new ProductoDAO();
    try {
        producto.setNombre(nombre);
        producto.setDescripcion(descripcion);
        producto.setPrecio(precio);
        producto.setCantidad(cantidad);
        producto.setCategoria(categoria);
    } catch (IllegalArgumentException ex) {
        JOptionPane.showMessageDialog(null, "Error al registrar producto: " + ex.getMessage());
        return;
    }

    listaProductos.add(producto);

    // Configurar cabeceras si aún no existen
    DefaultTableModel modelo = (DefaultTableModel) tempprod.getModel();

    if (modelo.getColumnCount() != 5) {
        modelo = new DefaultTableModel(
            new String[]{"NOMBRE", "DESCRIPCIÓN", "PRECIO", "CANTIDAD", "CATEGORÍA"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tempprod.setModel(modelo);
    }

    modelo.addRow(new Object[]{
        producto.getNombre(),
        producto.getDescripcion(),
        producto.getPrecio(),
        producto.getCantidad(),
        producto.getCategoria()
    });

    // Limpiar campos
    Nombre.setText("");
    Descripcion.setText("");
    Precio.setText("");
    Cantidad.setText("");
    Categoria.setText("");
}

public void modificarProductoEnTablaTemporal(JTable tempprod, JTextField Nombre, JTextField Descripcion, JTextField Precio, JTextField Cantidad, JTextField Categoria) {
    int filaSeleccionada = tempprod.getSelectedRow();

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Debe seleccionar una fila para modificar.");
        return;
    }

    if (Nombre.getText().isEmpty() || Descripcion.getText().isEmpty() || Precio.getText().isEmpty() || Cantidad.getText().isEmpty() || Categoria.getText().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Todos los campos deben estar completos.");
        return;
    }

    DefaultTableModel modelo = (DefaultTableModel) tempprod.getModel();

    modelo.setValueAt(Nombre.getText(), filaSeleccionada, 0);
    modelo.setValueAt(Descripcion.getText(), filaSeleccionada, 1);
    modelo.setValueAt(Precio.getText(), filaSeleccionada, 2);
    modelo.setValueAt(Cantidad.getText(), filaSeleccionada, 3);
    modelo.setValueAt(Categoria.getText(), filaSeleccionada, 4);

    JOptionPane.showMessageDialog(null, "Producto modificado correctamente en la tabla temporal.");
}

public void eliminarProductoDeTablaTemporal(JTable tempprod) {
    int filaSeleccionada = tempprod.getSelectedRow();

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(null, "Debe seleccionar una fila para eliminar.");
        return;
    }

    DefaultTableModel modelo = (DefaultTableModel) tempprod.getModel();
    modelo.removeRow(filaSeleccionada);

    JOptionPane.showMessageDialog(null, "Producto eliminado de la tabla temporal.");
}

public void cargarProductoTemporalEnCampos(JTable tempprod, JTextField Nombre, JTextField Descripcion, JTextField Precio, JTextField Cantidad, JTextField Categoria) {
    try {
        int fila = tempprod.getSelectedRow();
        if (fila != -1) {
            Nombre.setText(tempprod.getValueAt(fila, 0).toString());
            Descripcion.setText(tempprod.getValueAt(fila, 1).toString());
            Precio.setText(tempprod.getValueAt(fila, 2).toString());
            Cantidad.setText(tempprod.getValueAt(fila, 3).toString());
            Categoria.setText(tempprod.getValueAt(fila, 4).toString());
        } else {
            JOptionPane.showMessageDialog(null, "Debes seleccionar una fila.");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al seleccionar el producto temporal: " + e.toString());
    }
}

    public void mostrarProductos(JTable tablaClientes) {
        Conexion objetoConexion = new Conexion();

        DefaultTableModel modelo = new DefaultTableModel(
            new String[]{"ID","NOMBRE DEL PRODUCTO", "DESCRIPCION", "PRECIO UNITARIO", "CANTIDAD", "CATEGORIA"}, 0) { //tabla 
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        String sql = "SELECT  ID, Nombre_del_producto, Descripcion, Precio_unitario, Cantidad, Categoria FROM Productos";

        try (Connection conn = objetoConexion.establecerConexion();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String[] datos = new String[6]; //array
                datos[0] = rs.getString("ID");
                datos[1] = rs.getString("Nombre_del_producto");
                datos[2] = rs.getString("Descripcion");
                datos[3] = rs.getString("Precio_unitario");
                datos[4] = rs.getString("Cantidad");
                datos[5] = rs.getString("Categoria");
                modelo.addRow(datos);
            }

            tablaClientes.setModel(modelo);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar: " + e);
        } finally {
            objetoConexion.cerrarConexion();
        }
    }
    
     public void agregarProducto(JTable tempprod, JTable tablaProductos) {
    Conexion objetoConexion = new Conexion();
    String verificarNombreSQL = "SELECT COUNT(*) FROM Productos WHERE Nombre_del_producto = ?";
    String consultaInsertar = "INSERT INTO Productos (Nombre_del_producto, Descripcion, Precio_unitario, Cantidad, Categoria) VALUES (?, ?, ?, ?, ?)";

    try (Connection conn = objetoConexion.establecerConexion()) {
        DefaultTableModel modeloTemp = (DefaultTableModel) tempprod.getModel();
        int filas = modeloTemp.getRowCount();

        for (int i = 0; i < filas; i++) {
            String nombre = modeloTemp.getValueAt(i, 0).toString();
            String descripcion = modeloTemp.getValueAt(i, 1).toString();
            double precio = Double.parseDouble(modeloTemp.getValueAt(i, 2).toString());
            int cantidad = Integer.parseInt(modeloTemp.getValueAt(i, 3).toString());
            String categoria = modeloTemp.getValueAt(i, 4).toString();

            // Verificar si el producto ya existe por nombre
            try (PreparedStatement psVerificar = conn.prepareStatement(verificarNombreSQL)) {
                psVerificar.setString(1, nombre);
                ResultSet rs = psVerificar.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(null, "El producto '" + nombre + "' ya está registrado. Se omitirá ese registro.");
                    continue;
                }
            }

            // Insertar producto si no está duplicado
            try (PreparedStatement psInsertar = conn.prepareStatement(consultaInsertar)) {
                psInsertar.setString(1, nombre);
                psInsertar.setString(2, descripcion);
                psInsertar.setDouble(3, precio);
                psInsertar.setInt(4, cantidad);
                psInsertar.setString(5, categoria);
                psInsertar.executeUpdate();
            }
        }

        JOptionPane.showMessageDialog(null, "Productos agregados correctamente desde la tabla temporal.");
        mostrarProductos(tablaProductos); // Debes tener este método implementado

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al agregar productos desde tabla temporal: " + e.toString());
    } finally {
        objetoConexion.cerrarConexion();
    }
         
}
    
     
     public void cargarProductos(JTable tablaProductos, JTextField ID, JTextField Nombre_del_producto, JTextField Descripcion, JTextField Precio_unitario, JTextField Cantidad, JTextField Categoria) {
    try {
           int fila = tablaProductos.getSelectedRow(); 
           if (fila != -1) {
               
            ID.setText(tablaProductos.getValueAt(fila, 0).toString());
            Nombre_del_producto.setText(tablaProductos.getValueAt(fila, 1).toString());
            Descripcion.setText(tablaProductos.getValueAt(fila, 2).toString());
            Precio_unitario.setText(tablaProductos.getValueAt(fila, 3).toString());
            Cantidad.setText(tablaProductos.getValueAt(fila, 4).toString());
            Categoria.setText(tablaProductos.getValueAt(fila, 5).toString());
        }   
           else{
               JOptionPane.showMessageDialog(null, "No se pudo seleccionar");
           }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error de seleccion:" +e.toString());
    }
       
    }
     
     public void modificarProducto(JTextField ID, JTextField Nombre_del_producto, JTextField Descripcion, JTextField Precio_unitario, JTextField Cantidad, JTextField Categoria) {
    if (ID.getText().isEmpty()|| Nombre_del_producto.getText().isEmpty() || Descripcion.getText().isEmpty() || Precio_unitario.getText().isEmpty() || Cantidad.getText().isEmpty()|| Categoria.getText().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Todos los campos deben estar completos");
        return;
    }

    Conexion objetoConexion = new Conexion();
    String consulta = "UPDATE Productos SET Nombre_del_producto = ?, Descripcion = ?, Precio_unitario = ?, Cantidad  =?, Categoria =? WHERE ID = ?;";

    try (Connection conn = objetoConexion.establecerConexion()) {
        try (PreparedStatement psInsertar = conn.prepareStatement(consulta)) {
            psInsertar.setString(1, Nombre_del_producto.getText());
            psInsertar.setString(2, Descripcion.getText());
            psInsertar.setString(3, Precio_unitario.getText());
            psInsertar.setString(4, Cantidad.getText());
            psInsertar.setString(5, Categoria.getText());
            psInsertar.setString(6, ID.getText());
            psInsertar.executeUpdate();
            JOptionPane.showMessageDialog(null, "Se modifico el registro correctamente");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al modificar el registro: " + e.toString());
    } finally {
        objetoConexion.cerrarConexion();
    }
}
     
     public void eliminarProducto(JTextField idproducto) {
    Conexion objetoConexion = new Conexion();

    String consulta = "DELETE FROM Productos WHERE ID = ?";

    try (Connection conn = objetoConexion.establecerConexion();
         PreparedStatement ps = conn.prepareStatement(consulta)) {

        if (idproducto.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar un ID para eliminar.");
            return;
        }

        ps.setString(1, idproducto.getText());
        int filasAfectadas = ps.executeUpdate();

        if (filasAfectadas > 0) {
            JOptionPane.showMessageDialog(null, "Se eliminó el registro correctamente.");
        } else {
            JOptionPane.showMessageDialog(null, "No se encontró un cliente con ese ID.");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al eliminar el registro: " + e.toString());
    } finally {
        objetoConexion.cerrarConexion();
    }
}
     public void limpiarCampos(JTextField... campos) {
        for (JTextField campo : campos) {
            campo.setText("");
        }
    }
     public void buscarProductosPorTexto(JTable tabla, String texto) {
    DefaultTableModel modelo = new DefaultTableModel(
        new String[]{"ID", "NOMBRE", "DESCRIPCIÓN", "PRECIO", "CANTIDAD", "CATEGORÍA"}, 0
    ) {
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    Conexion conn = new Conexion();
    String sql = "SELECT * FROM Productos WHERE Nombre_del_producto LIKE ? OR Categoria LIKE ?";

    try (Connection con = conn.establecerConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, "%" + texto + "%");
        ps.setString(2, "%" + texto + "%");

        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            modelo.addRow(new Object[]{
                rs.getInt("ID"),
                rs.getString("Nombre_del_producto"),
                rs.getString("Descripcion"),
                rs.getDouble("Precio_unitario"),
                rs.getInt("Cantidad"),
                rs.getString("Categoria")
            });
        }
        tabla.setModel(modelo);

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al buscar productos: " + e.toString());
    } finally {
        conn.cerrarConexion();
    }
}
}
    
