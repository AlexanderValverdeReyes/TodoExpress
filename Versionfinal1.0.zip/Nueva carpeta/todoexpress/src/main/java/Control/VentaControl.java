package Control;


import DAO.ProductoDAO;
import DAO.VentaDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VentaControl {
    private JTable tablaVenta;
private JTextField txtnombre;
private JTextField txtDNI;
private JTextField txtsubtotal;
private JTextField txtdescuento;
private JTextField txttotal;
private DefaultTableModel modelo;

public VentaControl(JTable tablaVenta, JTextField txtnombre, JTextField txtDNI,
                    JTextField txtsubtotal, JTextField txtdescuento, JTextField txttotal) {
    this.tablaVenta = tablaVenta;
    this.txtnombre = txtnombre;
    this.txtDNI = txtDNI;
    this.txtsubtotal = txtsubtotal;
    this.txtdescuento = txtdescuento;
    this.txttotal = txttotal;
}

private int obtenerIdClientePorDni(String dni) {
    int idCliente = -1;
    Conexion cn = new Conexion();
    String sql = "SELECT ID FROM Clientes WHERE DNI = ?";
    
    try (Connection con = cn.establecerConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setString(1, dni);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            idCliente = rs.getInt("ID");
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return idCliente;
}

private int insertarVenta(int idCliente, double total, double descuento) {
    int idVenta = -1;
    Conexion cn = new Conexion();
    String sql = "INSERT INTO Venta (ID_cliente, Fecha, Total, descuento) VALUES (?, CURRENT_DATE, ?, ?)";

    try (Connection con = cn.establecerConexion();
         PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
        ps.setInt(1, idCliente);
        ps.setDouble(2, total);
        ps.setDouble(3, descuento);
        ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();
        if (rs.next()) {
            idVenta = rs.getInt(1);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return idVenta;
}

private int obtenerIdProductoPorNombre(String nombre) {
    int idProducto = -1;
    Conexion cn = new Conexion();
    String sql = "SELECT ID FROM Productos WHERE Nombre_del_producto = ?"; 

    try (Connection con = cn.establecerConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setString(1, nombre);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            idProducto = rs.getInt("ID"); 
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return idProducto;
}

private void insertarDetalleVenta(int idVenta, int idProducto, int cantidad, double precioUnitario, double subtotal) {
    Conexion cn = new Conexion();
    String sql = "INSERT INTO Detalle_venta (ID_venta, ID_producto, Cantidad, Precio_unitario, Subtotal) VALUES (?, ?, ?, ?, ?)";

    try (Connection con = cn.establecerConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, idVenta);
        ps.setInt(2, idProducto);
        ps.setInt(3, cantidad);
        ps.setDouble(4, precioUnitario);
        ps.setDouble(5, subtotal);
        ps.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
}

private void actualizarStock(int idProducto, int cantidadVendida) {
    Conexion cn = new Conexion();
    String sql = "UPDATE Productos SET Cantidad = Cantidad - ? WHERE ID = ?";

    try (Connection con = cn.establecerConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, cantidadVendida);
        ps.setInt(2, idProducto);
        ps.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
}

public void procesarVenta(JTable tablaVenta, JTextField txtDNI, JTextField txtnombre,
                              JTextField txtsubtotal, JTextField txtdescuento, JTextField txttotal) {

        if (tablaVenta.getRowCount() == 0 || txtDNI.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe ingresar productos y el DNI del cliente.");
            return;
        }

        int idCliente = obtenerIdClientePorDni(txtDNI.getText());
        if (idCliente == -1) {
            JOptionPane.showMessageDialog(null, "Cliente no encontrado.");
            return;
        }

        double total = Double.parseDouble(txttotal.getText().replace(",", "."));
        double descuento = Double.parseDouble(txtdescuento.getText().replace(",", "."));
        int idVenta = insertarVenta(idCliente, total, descuento);

        if (idVenta == -1) {
            JOptionPane.showMessageDialog(null, "Error al registrar la venta.");
            return;
        }

        DefaultTableModel modelo = (DefaultTableModel) tablaVenta.getModel();

        for (int i = 0; i < modelo.getRowCount(); i++) {
            String nombreProd = modelo.getValueAt(i, 0).toString();
            double precio = Double.parseDouble(modelo.getValueAt(i, 1).toString());
            int cantidad = Integer.parseInt(modelo.getValueAt(i, 2).toString());

            int idProducto = obtenerIdProductoPorNombre(nombreProd);
            if (idProducto == -1) {
                JOptionPane.showMessageDialog(null, "No se encontró el producto: " + nombreProd);
                continue;
            }

            double subtotal = precio * cantidad;
            insertarDetalleVenta(idVenta, idProducto, cantidad, precio, subtotal);
            actualizarStock(idProducto, cantidad);
        }

        JOptionPane.showMessageDialog(null, "Venta procesada correctamente.");
    }

public void generarComprobante() {
    String nombreCliente = txtnombre.getText();
    String dniCliente = txtDNI.getText();
    String subtotal = txtsubtotal.getText();
    String descuento = txtdescuento.getText();
    String total = txttotal.getText();

    StringBuilder comprobante = new StringBuilder();
    comprobante.append("======= COMPROBANTE DE PAGO =======\n");
    comprobante.append("Cliente: ").append(nombreCliente).append("\n");
    comprobante.append("DNI: ").append(dniCliente).append("\n");
    comprobante.append("-----------------------------------\n");
    comprobante.append(String.format("%-20s %-10s %-10s\n", "Producto", "Precio", "Cantidad"));

    // Recorremos la tabla de productos
    DefaultTableModel modelo = (DefaultTableModel) tablaVenta.getModel();
    for (int i = 0; i < modelo.getRowCount(); i++) {
        String producto = modelo.getValueAt(i, 0).toString();
        String precio = modelo.getValueAt(i, 1).toString();
        String cantidad = modelo.getValueAt(i, 2).toString();
        comprobante.append(String.format("%-20s %-10s %-10s\n", producto, precio, cantidad));
    }

    comprobante.append("-----------------------------------\n");
    comprobante.append("Subtotal: ").append(subtotal).append("\n");
    comprobante.append("Descuento: ").append(descuento).append("\n");
    comprobante.append("TOTAL: ").append(total).append("\n");
    comprobante.append("===================================");

    JOptionPane.showMessageDialog(null, comprobante.toString(), "Comprobante de Pago", JOptionPane.INFORMATION_MESSAGE);
}
    // Configura la cabecera de la tabla de ventas
    public void cabeceraVentas(JTable tablaVentas) {
        String[] cabecera = {"PRODUCTO", "SUBTOTAL"};//array
        modelo = new DefaultTableModel(cabecera, 0);//tabla
        tablaVentas.setModel(modelo);
    }

    // Calcula el subtotal de un producto
    public double calcularSubtotal(JTextField cantidad, JTable tablaProductos) {
        if (tablaProductos.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione un producto");
            return 0;
        }

        try {
            double precio = Double.parseDouble(tablaProductos.getValueAt(tablaProductos.getSelectedRow(), 2).toString());
            int cant = Integer.parseInt(cantidad.getText());
            return precio * cant;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Cantidad debe ser un número válido");
            return 0;
        }
    }

    // Calcula el total de la venta
    public double calcularTotal(JTable tablaVentas) {
        double total = 0;
        for (int i = 0; i < tablaVentas.getRowCount(); i++) {
            total += Double.parseDouble(tablaVentas.getValueAt(i, 1).toString());
        }
        return total;
    }

    // Aplica descuento según el monto total
    public double aplicarDescuento(double total) {
        if (total >= 100 && total <= 250) {
            return total * 0.2;
        } else if (total > 250 && total <= 350) {
            return total * 0.4;
        } else if (total > 350) {
            return total * 0.5;
        }
        return 0;
    }

    // Agrega un producto a la venta
    public void agregarProductoAVenta(JTextField cantidad, JTable tablaProductos, JTable tablaVentas,
                                     JTextField txtSubtotal, JTextField txtDescuento, JTextField txtTotal,
                                     JLabel lblTipoDescuento) {
        if (cantidad.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese la cantidad");
            return;
        }

        double subtotal = calcularSubtotal(cantidad, tablaProductos);
        if (subtotal > 0) {
            modelo.addRow(new Object[]{ //array
                tablaProductos.getValueAt(tablaProductos.getSelectedRow(), 0),
                subtotal
            });

            double total = calcularTotal(tablaVentas);
            double descuento = aplicarDescuento(total);
            double totalConDescuento = total - descuento;

            txtSubtotal.setText(String.valueOf(total));
            txtDescuento.setText(String.valueOf(descuento));
            txtTotal.setText(String.valueOf(totalConDescuento));
            lblTipoDescuento.setText(descuento > 0 ? (descuento == total * 0.2 ? "20%" : 
                                                     descuento == total * 0.4 ? "40%" : "50%") : "0%");
            cantidad.setText("");
        }
    }
    
public double calcularTotalDesdeVenta(VentaDAO venta) {
    double total = 0;
    for (ProductoDAO p : venta.getProductos()) {
        total += p.getCantidad() * p.getPrecio();
    }
    return total;
}
    // Elimina un producto de la venta
   public void eliminarProductoDeVenta(JTable tablaVentas, JTextField txtSubtotal,
                                    JTextField txtDescuento, JTextField txtTotal,
                                    JLabel lblTipoDescuento, VentaDAO ventaActual, List<ProductoDAO> listaProductos) {

    int fila = tablaVentas.getSelectedRow();
    if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Seleccione un producto para eliminar.");
        return;
    }

    DefaultTableModel modelo = (DefaultTableModel) tablaVentas.getModel();

    // Obtener nombre y cantidad del producto eliminado
    String nombreProducto = tablaVentas.getValueAt(fila, 0).toString();
    int cantidadEliminada = (int) Double.parseDouble(tablaVentas.getValueAt(fila, 1).toString());


    // Remover el producto de la tabla visual
    modelo.removeRow(fila);

    // Remover el producto también de la lista en ventaActual
    List<ProductoDAO> productosVenta = ventaActual.getProductos();
    ProductoDAO productoRemovido = null;
    for (ProductoDAO p : productosVenta) {
        if (p.getNombre().equals(nombreProducto)) {
            productoRemovido = p;
            break;
        }
    }
    if (productoRemovido != null) {
        productosVenta.remove(productoRemovido);
    }

    // Restaurar stock en listaProductos
    for (ProductoDAO p : listaProductos) {
        if (p.getNombre().equals(nombreProducto)) {
            p.setCantidad(p.getCantidad() + cantidadEliminada);
            break;
        }
    }

    // Recalcular totales
    double total = calcularTotal(tablaVentas);
    double descuento = aplicarDescuento(total);
    double totalConDescuento = total - descuento;

    txtSubtotal.setText(String.valueOf(total));
    txtDescuento.setText(String.valueOf(descuento));
    txtTotal.setText(String.valueOf(totalConDescuento));

    lblTipoDescuento.setText(
        descuento > 0 ? (descuento == total * 0.2 ? "20%" :
                         descuento == total * 0.4 ? "40%" : "50%") : "0%"
    );
}
}